<!DOCTYPE html> 
<html lang="en">
<head>
<title>Weather Wizard</title>
<meta charset="UTf=8"/>
<link rel= "stylesheet" href="weatherstyles.css">
<link href="https://fonts.googleapis.com/css?family=Merriweather:400,700" rel="stylesheet">
<meta name="keywords" content="weather, temperature, station">
<meta name="description" content="filters for different weather types and show different weather patterns">
<!--[If lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
<?php
$servername= "localhost";
$username= "test"; 
$password= "jbHum;5234";
$database= "ServerJS";

// Connect to Database 
$conn = new mysqli($servername, $username, $password, $database); 

// Check Connection 
if ($conn -> connect_error) {
 die("Connection failed: " . $conn->connect_error);
 }
 ?>
</head>

<body>
<header>WeatherWizard Map</header>
<div class="dropdown">
<button class="dropbtn">Menu</button>
<div class="dropdown-content">
<ul>
<nav>
<li><ahref ="home.html">Home</a></li>
<li><ahref="WorldMap.html">WorldMap</a></li>
<li><ahref="Analysis.html">Analysis</a></li>
</nav>
</ul>
</div>
</div>
<h1>World Map</h1>
<p>Look at the weather patterns from different stations during 2018.</p>
<iframe src="https://www.google.com/maps/embed?pb=" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe><br>
<table>
<tr>
<th>Station</th>
<th>Temp_max</th>
<th>Temp_min</th>
<th>Latitude</th>
<th>Longitude</th>
</tr>
<tr>
<td>Toronto</td>
<td>40.1</td>
<td>34.9</td>
<td>43.6532N</td>
<td>79.3832W</td>
</tr>
<tr>
<td>Montreal</td>
<td>73.4</td>
<td>57.2</td>
<td>45.5017N</td>
<td>73.5673W</td>
</tr>
<tr>
<td>New York (10010)</td>
<td>28.6</td>
<td>27.5</td>
<td>40.7128N</td>
<td>74.0060W</td>
</tr>
<tr>
<td>Chicago</td>
<td>35.1</td>
<td>32</td>
<td>41.881832N</td>
<td>87.623177W</td>
</tr>
<tr>
<td>Vancouver</td>
<td>33.6</td>
<td>29.7</td>
<td>49.2827N</td>
<td>123.1207W</td>
</tr>
</table>
<h2>Figure 1: Weather Station: Temperature Graphs</h2>
<img src="images/Figure_1.png" alt="maxtemp" weight=400px height=250px> <br>
<p>Showcasing 4 random weather stations and their max temperature.</p>
<?php
	
	// Select from Table 
	$sql =  'Select from Table'
	$sql = 'Select Station, Temp_max, Temp_min, Temp_avg, Temp_cnt * From GSOD2018 Order By Temp_max ASC';
	$result = $conn->query($sql);
	
	if (mysqli_num_rows($result) > 0) {
	
	  // set up the html table 
	  echo "<table><tr><th>Station</th><th>Temp_max</th><th>Temp_min</th><th>Temp_avg</th><th>Temp_cnt</th></tr>";
	  
	  // output data of each row 
	  while ($row = $result->fetch_assoc()) { 
	      echo "<tr><td>".$row["Station"]. "</td><td>". "</td><td>".$row["Temp_max"]. "</td><td>". "</td><td>".$row["Temp_min"]. "</td><td>". "<tr><td>".$row["Temp_avg"]. "</td><td>". "</td><td>".$row["Temp_cnt"]. "</td><tr>";
		  }
		  echo "</table>";
		  }
		  else {
		  echo "No Results";
		  }
		  $conn->close();
		  
?> 

<h1>Figure 2: Latitude and Longitude on Weather Stations</h1>
<img src="images/Figure_2(a).png" alt="LatandLong" weight=400px height=250px> <br>
<img src="images/Figure_2(b).png" alt="Maxandmin" weight=400px height=250px> <br>

<?php

	// Select from Table 
	$sql = 'Select from Table'
	$sql = 'Select Station, Latitude, Longitude * From GSOD2018';
	$result = $conn->query($sql); 
	
	if(mysqli_num_rows($result)>0) { 
	
	//set up the html table 
	echo "<table><tr><th>Station</th><th>Latitude</th><th>Longitude</th>";
	
	//output data of each row 
	while($row = $result->fetch_assoc()) {
		echo "<tr><td>".$row["Station"]. "</td><td>"."</td><td>".$row["Latitude"]."</td><td>"."</td><td>".$row["Longitude"]."</td><td>".
	}
	echo "</table>";
	}
	else {
		echo "No Results";
	}
	$conn->close();
?>

<h1>Figure 3: Max Wind Speed</h1>
<img src="images/Figure_3.png" alt="windspeed" weight=850px height=350px> <br>

<?php

	// Select from Table 
	$sql = 'Select from Table'
	$sql = 'Select Station, YearMod, Wdsp_avg * From GSOD2018';
	$result = $conn->query($sql); 
	
	if(mysqli_num_rows($result)>0) { 
	
	//set up the html table 
	echo "<table><tr><th>Station</th><th>YearMod</th><th>Wdsp_avg</th>">
	
	//output data of each row 
	while($row = $result->fetch_assoc()) {
		echo "<tr><td>".$row["Station"]. "</td><td>"."</td><td>".$row["YearMod"]."</td><td>"."</td><td>".$row["Wdsp_avg"]."</td><td>".
	}
	echo "</table>";
	}
	else {
		echo "No Results";
	}
	}
	$conn->close();
?>

<h1>Total Precipitation</h1>

<?php

	// Select from Table 
	$sql = 'Select from Table'
	$sql = 'Select Station, YearMod, Prcp_tot * From GSOD2018 Order By Prcp_tot ASC' ;
	$result = $conn->query($sql); 
	
	if(mysqli_num_rows($result)>0) { 
	
	//set up the html table 
	echo "<table><tr><th>Station</th><th>YearMod</th><th>Prcp_tot</th>">
	
	//output data of each row 
	while($row = $result->fetch_assoc()) {
		echo "<tr><td>".$row["Station"]. "</td><td>"."</td><td>".$row["YearMod"]."</td><td>"."</td><td>".$row["Prcp_tot"]."</td><td>".
	}
	echo "</table>";
	}
	else {
		echo "No Results";
	}
	}
	$conn->close();
?>
</body>
</html>