<!DOCTYPE html> 
<html lang="en">
<head>
<title>Weather Wizard</title>
<meta charset="UTF-8"/>
<link rel= "stylesheet" href="weatherstyles.css">
<link href="https://fonts.googleapis.com/css?family=Merriweather:400,700" rel="stylesheet">
<meta name="keywords" content="weather, temperature, station">
<meta name="description" content="filters for different weather types and show different weather patterns">
<!--[If lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
<?php
$servername= "localhost";
$username= "joshweb"; 
$password= "mYW36s!T3";
$database= "ServerJS";

// Connect to Database 
$conn = new mysqli($servername, $username, $password, $database); 

// Check Connection 
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
}

echo "Connected succesfully";
?>

</head>

<body>
<header>WeatherWizard</header>
<div class="dropdown">
<button onclick="myFunction()" class="dropbtn">Menu</button>
<div id="myDropdown" class="dropdown-content">
<input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
<nav>
<ul>
<li><ahref="index.html">Home</a></li>
<li><ahref="about.html">About</a></li>
<li><ahref="WorldMap.html">WorldMap</a></li>
<li><ahref="Analysis.html">Analysis</a></li>
</ul>
</nav>
</div>
</div>
<h1>World Map</h1>
<p>Look at the weather patterns from different stations during 2018.</p>
<iframe src="https://www.google.com/maps/embed?pb=" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe><br>
<table>
<tr>
<th>Station</th>
<th>Temp_max</th>
<th>Temp_min</th>
<th>Latitude</th>
<th>Longitude</th>
</tr>
<tr>
<td>Toronto</td>
<td>40.1</td>
<td>34.9</td>
<td>43.6532N</td>
<td>79.3832W</td>
</tr>
<tr>
<td>Montreal</td>
<td>73.4</td>
<td>57.2</td>
<td>45.5017N</td>
<td>73.5673W</td>
</tr>
<tr>
<td>New York (10010)</td>
<td>28.6</td>
<td>27.5</td>
<td>40.7128N</td>
<td>74.0060W</td>
</tr>
<tr>
<td>Chicago</td>
<td>35.1</td>
<td>32</td>
<td>41.881832N</td>
<td>87.623177W</td>
</tr>
<tr>
<td>Vancouver</td>
<td>33.6</td>
<td>29.7</td>
<td>49.2827N</td>
<td>123.1207W</td>
</tr>
</table>

<div>
<h2>Figure 1: Weather Station: Temperature Graphs</h2>
<img src="images/Figure_1.png" alt="maxtemp" weight=400px height=250px> <br>
<p>Showcasing 4 random weather stations and their max temperature.</p>
<?php

	$plyrid=$_POST['GSOD2018'];
	echo $plyrid; 
	if (isset($_POST['Submit'])) {
		echo "<table><tr><th>station</th><th>Temp_max</th><th>Temp_min</th><th>Temp_avg</th></tr>";
		
		$sql="SELECT station, temp_max, temp_min, temp_avg FROM GSOD2018 = '$plyrid'";
		/*result=$conn->query("SELECT station, temp_max, temp_min, temp_avg FROM GSOD2018 WHERE station = '$plyrid' ORDER BY temp_max DESC"); */
		$result = $conn -> query($sql);
		if ($result->num_rows > 0) {
			while($row=$result->fetch_assoc()) {
				echo "<tr><td>" .$row["station"]. "</td><td>" .$row["Temp_max"]. "</td><td>" .$row["Temp_min"]. "</td><td>" .$row["Temp_avg"]. "</td></tr>";
			}
		}
			else {
				echo "Nothing";
			}
				echo "</table>";
	}
?>

<h1>Figure 2: Latitude and Longitude on Weather Stations</h1>
<img src="images/Figure_2(a).png" alt="LatandLong" weight=400px height=250px> <br>
<img src="images/Figure_2(b).png" alt="Maxandmin" weight=400px height=250px> <br>

<?php
<?php

	$plyrid=$_POST['GSOD2018'];
	echo $plyrid; 
	if (isset($_POST['Submit'])) {
		echo "<table><tr><th>station</th><th>Latitude</th><th>Longitude</th></tr>";
		
		$sql="SELECT station, Latitude, Longitude FROM GSOD2018 = '$plyrid'";
		/*result=$conn->query("SELECT station, latitude, longitude FROM GSOD2018 WHERE station = '$plyrid' ORDER BY latitude DESC"); */
		$result = $conn -> query($sql);
		if ($result->num_rows > 0) {
			while($row=$result->fetch_assoc()) {
				echo "<tr><td>" .$row["station"]. "</td><td>" .$row["Latitude"]. "</td><td>" .$row["Longitude"]. "</td></tr>";
			}
		}
			else {
				echo "Nothing";
			}
				echo "</table>";
	}
?>
<h1>Figure 3: Max Wind Speed</h1>
<img src="images/Figure_3.png" alt="windspeed" weight=850px height=350px> <br>

<?php

	// Select from Table 
	$sql = 'Select from Table'
	$sql = 'Select Station, YearMod, Wdsp_avg * From GSOD2018';
	$result = $conn->query($sql); 
	
	if(mysqli_num_rows($result)>0) { 
	
	//set up the html table 
	echo "<table><tr><th>Station</th><th>YearMod</th><th>Wdsp_avg</th>">
	
	//output data of each row 
	while($row = $result->fetch_assoc()) {
		echo "<tr><td>".$row["Station"]."</td><td>"."</td><td>".$row["YearMod"]."</td><td>"."</td><td>".$row["Wdsp_avg"]."</td><td>";
	}
	echo "</table>";
	}
	else {
		echo "No Results";
	}
	$conn->close();
?>

<h1>Total Precipitation</h1>

<?php

	// Select from Table 
	$sql = 'Select from Table'
	$sql = 'Select Distinct Prcp_tot * From GSOD2018 Order By Prcp_tot ASC' ;
	$result = $conn->query($sql); 
	
	if(mysqli_num_rows($result)>0) { 
	
	//set up the html table 
	echo "<table><tr><th>Station</th><th>YearMod</th><th>Prcp_tot</th>">
	
	//output data of each row 
	while($row = $result->fetch_assoc()) {
		echo "<tr><td>".$row["Station"]."</td><td>"."</td><td>".$row["YearMod"]."</td><td>"."</td><td>".$row["Prcp_tot"]."</td><td>";
	}
	echo "</table>";
	}
	else {
		echo "No Results";
	}
	$conn->close();
?>
</div>

<script>
function myFunction ( ) {
	document.getElementById("myDropdown").classList.toggle("show"); 
	}

function filterFunction( ) {
	var input, filter, ul, li, a, i;
	input = document.getElementById("myInput"); 
	filter = input.value.toUpperCase();
	div = document.getElementById("myDropdown"); 
	a = div.getElementsByTagName("a"); 
	 for (i=0; i < a. length; i++) {
	 	txtValue = a[i]. textContent || a[i].innerText;
		if (txtValue.toUpperCase( ).indexOf(filter) > -1) {
			a[i].style.display = "";
		} else {
			a[i].style.display = "none";
		}
	 }
}	
</script>

</body>
</html>